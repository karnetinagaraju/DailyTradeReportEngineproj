package com.report;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import com.report.bean.ReportEngineInput;
/**
 * 
  * @author Mr 
 */
public class DailyTradeReportEngineTest {	

	@Test
	public void testDocumentProvidedData() {

		String reportData = "foo,B,0.50,SGP,01 Jan 2016,06 Jul 2018,200,100.25;"
				            +"bar,S,0.22,AED,05 Jan 2016,07 Jul 2018,450,150.5";		
				

		DailyTradeReportEngine dailyTradeReportEngine = new DailyTradeReportEngine(reportData);
		//check the incomingList size
		List<ReportEngineInput> incomingList = dailyTradeReportEngine.getIncomingList();		
		assertEquals(1, incomingList.size());
		//check the outgoingList size
		List<ReportEngineInput> outgoingList = dailyTradeReportEngine.getOutComingList();
		assertEquals(1, incomingList.size());			
		//check the everdayIncomingTotalMap size
		Map<Date,Double> everdayIncomingTotal = dailyTradeReportEngine.everydayIncomingUsd();
		assertEquals(1, everdayIncomingTotal.size());
		//check the everdayOutGoingTotalMap size
		Map<Date,Double> everdayOutGoingTotal = dailyTradeReportEngine.everydayOutgoingUsd();		
		assertEquals(1, everdayIncomingTotal.size());		
	}
	
}
