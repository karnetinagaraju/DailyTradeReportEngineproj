package com.report.util;


/** 
 * @author Mr 
 */
public class CommonConstants {
	
	public  final static String REPORTDATE = "dd MMM yyy";
	public  final static String CURRENCY_AED = "AED";
	public  final static String CURRENCY_SAR = "SAR";
	public  final static String SELL = "S";
	public  final static String FRI = "Friday";
	public  final static String SAT = "Saturday";
	public  final static String SUN = "Sunday";

}
