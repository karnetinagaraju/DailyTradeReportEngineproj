package com.report.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/** 
 * @author Mr 
 */
public class ReportDataUtil {		
	/**	 
	 * @param strDate
	 * @return
	 */
	public static Date convertStringtoDate(String strDate ,String format){
		Date date = null;
		try {
			date = new SimpleDateFormat(format).parse(strDate);			
		} catch (ParseException e) {			
			e.printStackTrace();
		}
		return date;
	}
	
	/**	 
	 * @param date
	 * @param days
	 * @return
	 */
	public static Date addDays(Date date, int days)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); //minus number would decrement the days
        return cal.getTime();
    }



}
