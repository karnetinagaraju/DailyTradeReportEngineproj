package com.report;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.report.bean.ReportEngineInput;
import com.report.util.CommonConstants;
import com.report.util.ReportDataUtil;




/**
  * @author Mr 
 */
public class DailyTradeReportEngine {	
	
	private final static Logger logger =  Logger.getLogger("DailyTradeReportEngine");
	
	private List<ReportEngineInput> inComigListReport = new ArrayList<ReportEngineInput>(); 
	private List<ReportEngineInput> outGoingList = new ArrayList<ReportEngineInput>();
    /**   
     * @param reportData
     */
	public DailyTradeReportEngine(String reportData) {
		String[] rowColumns = null;
		Date instructionDate, settlementDate = null;		
		String[] reportRows = reportData.split(";");
		for (int i = 0; i < reportRows.length; i++) {
			String reportRow = reportRows[i];
			rowColumns = reportRow.split(",");
			instructionDate = ReportDataUtil.convertStringtoDate(rowColumns[4], CommonConstants.REPORTDATE);
			settlementDate = ReportDataUtil.convertStringtoDate(rowColumns[5], CommonConstants.REPORTDATE);
			ReportEngineInput reportEngineInput = new ReportEngineInput(rowColumns[0], rowColumns[1],
					Float.parseFloat(rowColumns[2]), rowColumns[3], instructionDate, settlementDate,
					Float.parseFloat(rowColumns[6]), Float.parseFloat(rowColumns[7]));
			if (rowColumns[1].equalsIgnoreCase(CommonConstants.SELL)) {
				inComigListReport.add(reportEngineInput);
			} else {
				outGoingList.add(reportEngineInput);
			}
			
		}
		Collections.sort(inComigListReport);
		Collections.sort(outGoingList);
	}
	
	/**	 
	 * @return
	 */
	public List<ReportEngineInput> getIncomingList() {		

		System.out.println("Entity\t" + "TransMode\t" + "AgreedFx\t" + "Currency" + "InstructionDate\t\t\t"
				+ "SettlementDate\t\t\t" + "Units\t" + "PricePerUnit\t" +"UsdAmount\t"+"AdjSettlementDate\t\t"+"Rank");
		for (int i = 0; i < inComigListReport.size(); i++) {
			System.out.print(inComigListReport.get(i).getEntity() + "\t");
			System.out.print(inComigListReport.get(i).getTransmode() + "\t\t");
			System.out.print(inComigListReport.get(i).getAgreedFx() + "\t\t");
			System.out.print(inComigListReport.get(i).getCurrency() + "\t");
			System.out.print(inComigListReport.get(i).getInstructionDate() + "\t");
			System.out.print(inComigListReport.get(i).getSettlementDate() + "\t");
			System.out.print(inComigListReport.get(i).getUnits() + "\t");
			System.out.print(inComigListReport.get(i).getPricePerUnit() + "\t\t");
			System.out.print(inComigListReport.get(i).getUsdAmount()+"\t\t");
			System.out.print(inComigListReport.get(i).getAdjSettlementDate()+"\t");	
			System.out.println(i+1);
		}		
		return inComigListReport;
	}
	
   /**    
    * @return
    */
	public List<ReportEngineInput> getOutComingList() {
		System.out.println("Entity\t" + "TransMode\t" + "AgreedFx\t" + "Currency" + "InstructionDate\t\t\t"
				+ "SettlementDate\t\t\t" + "Units\t" + "PricePerUnit\t" +"UsdAmount\t"+"AdjSettlementDate\t\t"+"Rank");
		for (int i = 0; i < outGoingList.size(); i++) {
			System.out.print(outGoingList.get(i).getEntity() + "\t");
			System.out.print(outGoingList.get(i).getTransmode() + "\t\t");
			System.out.print(outGoingList.get(i).getAgreedFx() + "\t\t");
			System.out.print(outGoingList.get(i).getCurrency() + "\t");
			System.out.print(outGoingList.get(i).getInstructionDate() + "\t");
			System.out.print(outGoingList.get(i).getSettlementDate() + "\t");
			System.out.print(outGoingList.get(i).getUnits() + "\t");
			System.out.print(outGoingList.get(i).getPricePerUnit() + "\t\t");
			System.out.print(outGoingList.get(i).getUsdAmount()+"\t\t");
			System.out.print(outGoingList.get(i).getAdjSettlementDate()+"\t");
			System.out.println(i+1);
		}		
		return outGoingList;
		
	}

	/**	 
	 * @return
	 */
	public Map<Date, Double> everydayIncomingUsd() {
		Map<Date, Double> everydayIncomingHashMap = new HashMap<Date, Double>();
		double UsdIncomingAmout = 0;
		for (int i = 0; i < inComigListReport.size(); i++) {
			if (everydayIncomingHashMap.containsKey(inComigListReport.get(i).getAdjSettlementDate())) {
				UsdIncomingAmout = everydayIncomingHashMap.get(inComigListReport.get(i).getAdjSettlementDate())
						+ inComigListReport.get(i).getUsdAmount();
			} else {
				UsdIncomingAmout = inComigListReport.get(i).getUsdAmount();
			}
			everydayIncomingHashMap.put(inComigListReport.get(i).getAdjSettlementDate(), UsdIncomingAmout);
		}
		logger.log(Level.INFO, "everydayIncomingHashMap::" + everydayIncomingHashMap.toString());
		return everydayIncomingHashMap;
	}
	
	/**	 
	 * @return
	 */
	public Map<Date,Double> everydayOutgoingUsd() {
		Map<Date, Double> everydayOutgoingHashMap = new HashMap<Date, Double>();
		double usdOutgoingAmout = 0;
		for (int i = 0; i < outGoingList.size(); i++) {
			if (everydayOutgoingHashMap.containsKey(outGoingList.get(i).getAdjSettlementDate())) {
				usdOutgoingAmout = everydayOutgoingHashMap.get(outGoingList.get(i).getAdjSettlementDate())+ outGoingList.get(i).getUsdAmount();
			} else {				
				usdOutgoingAmout =  outGoingList.get(i).getUsdAmount();
				
			}
			everydayOutgoingHashMap.put(outGoingList.get(i).getAdjSettlementDate(),usdOutgoingAmout);
		}
		logger.log(Level.INFO,"Every day total for UsdOutgoingAmout:::::" + everydayOutgoingHashMap);
		return everydayOutgoingHashMap;
	}	
	
}	