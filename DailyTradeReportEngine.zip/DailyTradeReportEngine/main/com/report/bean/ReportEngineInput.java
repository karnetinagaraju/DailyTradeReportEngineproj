package com.report.bean;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import com.report.util.CommonConstants;
import com.report.util.ReportDataUtil;

/**
 *ReportEngineInput 
 */
public class ReportEngineInput implements  Comparable<ReportEngineInput>{
	
	private final static Logger logger =  Logger.getLogger("ReportEngineInput");;
	
	private String entity;	
	private String transMode;	
	private Float agreedFx;
	private String currency;
	private Date instructionDate;
	private Date adjSettlementDate;
	private Date settlementDate;
	private Float units;
	private Float pricePerUnit;
	private Double usdAmount;	
	
	/**
	 * 
	 * @param entity
	 * @param transmode
	 * @param agreedFx
	 * @param currency
	 * @param instructionDate
	 * @param settlementDate
	 * @param units
	 * @param pricePerUnit
	 */
	public ReportEngineInput(String entity, String transmode,Float agreedFx, String currency, Date instructionDate,
			Date settlementDate,Float units, Float pricePerUnit){		
		
		this.entity = entity;
		this.transMode = transmode;	
		this.agreedFx = agreedFx;
		this.currency = currency;
		this.instructionDate = instructionDate;
		this.settlementDate = settlementDate;
		this.units = units;
		this.pricePerUnit = pricePerUnit;
		
		this.usdAmount = (double) (pricePerUnit * units * agreedFx);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
		simpleDateFormat.format(settlementDate);
		// work week starts from Sunday and ends on Thursday
		if (currency.equalsIgnoreCase(CommonConstants.CURRENCY_AED) || currency.equalsIgnoreCase(CommonConstants.CURRENCY_SAR)) {
			if (CommonConstants.FRI.equalsIgnoreCase(simpleDateFormat.format(settlementDate))) {				
				this.adjSettlementDate = ReportDataUtil.addDays(settlementDate, 2);
			} else if (CommonConstants.SAT.equalsIgnoreCase(simpleDateFormat.format(settlementDate))){
				this.adjSettlementDate = ReportDataUtil.addDays(settlementDate, 1);
			}else{
				this.adjSettlementDate = settlementDate;
			}
			
		} else {
			// work week starts from Monday and ends on Friday
			if (CommonConstants.SAT.equalsIgnoreCase(simpleDateFormat.format(settlementDate))) {
				this.adjSettlementDate = ReportDataUtil.addDays(settlementDate, 2);
			} else if(CommonConstants.SUN.equalsIgnoreCase(simpleDateFormat.format(settlementDate))){
				this.adjSettlementDate = ReportDataUtil.addDays(settlementDate, 1);
			}else{
				this.adjSettlementDate = settlementDate;
			}
		}		
	}
		
		@Override
		public int compareTo(ReportEngineInput object) {			
			return (int) (object.getUsdAmount() -this.usdAmount);
		}

		public String getEntity() {
			return entity;
		}



		public String getTransmode() {
			return transMode;
		}



		public Float getAgreedFx() {
			return agreedFx;
		}



		public String getCurrency() {
			return currency;
		}



		public Date getInstructionDate() {
			return instructionDate;
		}



		public Date getAdjSettlementDate() {
			return adjSettlementDate;
		}



		public Date getSettlementDate() {
			return settlementDate;
		}



		public Float getUnits() {
			return units;
		}



		public Float getPricePerUnit() {
			return pricePerUnit;
		}



		public Double getUsdAmount() {
			return usdAmount;
		}

		
}
